# GithubUserApp
Aplikasi yang dibuat untuk memenuhi syarat kelulusan online course "Belajar Fundamental Aplikasi Android" yang di buat oleh Dicoding

## Submission 1
Membuat aplikasi android yang berisikan listview / recyclelistview dan detail dari list tersebut